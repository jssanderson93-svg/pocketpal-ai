# Build manifest / gate state

## Completed without physical hardware

- [x] PocketPal Talent architecture verified against source.
- [x] AgentRunner tool-result feedback path verified against source.
- [x] Mock `flipper_status` Talent implemented.
- [x] Mock Talent direct unit test written.
- [x] AgentRunner integration test written.
- [x] Phase-1 unified patch mechanically passes `git apply --check` against the verified upstream `index.ts` layout.
- [x] Official Flipper `PB.Main` schema inspected and pinned.
- [x] Official firmware confirms protobuf-delimited framing in both directions.
- [x] Dependency-free delimited-stream codec implemented.
- [x] Production stream-codec TypeScript passes standalone strict `tsc --noEmit`.
- [x] Stream runtime check passes every two-chunk split and one-byte-at-a-time fragmentation.
- [x] Official Flipper iOS BLE UUIDs verified.
- [x] Official Flipper iOS scan strategy verified.
- [x] Official flow-control endian/direction/write behavior verified.
- [x] CoreBluetooth diagnostic module source implemented.
- [x] Native module validates expected GATT characteristic properties before declaring readiness.
- [x] Xcode project patch is fail-closed on verified structural anchors.
- [x] Info.plist Bluetooth insertion corrected so it does not split an existing key/value pair.
- [x] Patched Info.plist is parsed with `plistlib` before being written.
- [x] Audited PocketPal iOS CI build configuration (`Env.xcconfig`, `.env`, `GoogleService-Info.plist`) is staged by the bootstrap.
- [x] Bootstrap validates both plist files and the required xcconfig keys before reporting success.
- [x] GitHub Actions run 33267646668 passed all three targeted Flipper suites: 15/15 tests.
- [x] GitHub Actions run 33267646668 completed CocoaPods installation before Xcode failed on the missing `Env.xcconfig` gate.

## Cannot be truthfully marked complete without the next Mac/Xcode + physical iPhone/Flipper gates

- [ ] Xcode compile/link of the new CoreBluetooth module.
- [ ] Unsigned IPA packaging.
- [ ] iOS signing/install of the custom build.
- [ ] iOS Bluetooth permission prompt.
- [ ] Discovery of the physical Flipper through `3080-3083`.
- [ ] Bond/PIN exchange.
- [ ] Physical GATT fingerprint capture.
- [ ] Physical flow-control value capture.
- [ ] Protobuf-version query from the actual device.
- [ ] First Ping RPC.

No firmware change is justified before the physical GATT/RPC gates above provide positive evidence of incompatibility.

#!/usr/bin/env python3
"""Deterministically add FlipperBLEModule to PocketPal's iOS target.

Expected base: a-ghorbani/pocketpal-ai commit
ed680864adea0b090dac173b27675987c000fef2

The script is deliberately fail-closed: every structural anchor must occur
exactly once before any file is written, and the transformed Info.plist must
parse successfully before it is committed to disk.
"""
from __future__ import annotations

from pathlib import Path
import plistlib
import sys

ROOT = Path(__file__).resolve().parents[1]
PBX = ROOT / "ios/PocketPal.xcodeproj/project.pbxproj"
PLIST = ROOT / "ios/PocketPal/Info.plist"

BLUETOOTH_USAGE = (
    "PocketPal uses Bluetooth to connect to your paired Flipper Zero for "
    "local device status and RPC control."
)


def insert_once(text: str, anchor: str, insertion: str, label: str) -> str:
    count = text.count(anchor)
    if count != 1:
        raise RuntimeError(f"{label}: expected anchor exactly once, found {count}")
    return text.replace(anchor, anchor + insertion, 1)


def insert_before_once(text: str, anchor: str, insertion: str, label: str) -> str:
    count = text.count(anchor)
    if count != 1:
        raise RuntimeError(f"{label}: expected anchor exactly once, found {count}")
    return text.replace(anchor, insertion + anchor, 1)


def main() -> int:
    pbx = PBX.read_text()
    plist = PLIST.read_text()

    if "FlipperBLEModule.swift in Sources" not in pbx:
        pbx = insert_once(
            pbx,
            "\t\tAB1001010000000000000002 /* AuthSessionModule.m in Sources */ = {isa = PBXBuildFile; fileRef = AB1001010000000000000004 /* AuthSessionModule.m */; };\n",
            "\t\tFB3000010000000000000001 /* FlipperBLEModule.swift in Sources */ = {isa = PBXBuildFile; fileRef = FB3000010000000000000003 /* FlipperBLEModule.swift */; };\n"
            "\t\tFB3000010000000000000002 /* FlipperBLEModule.m in Sources */ = {isa = PBXBuildFile; fileRef = FB3000010000000000000004 /* FlipperBLEModule.m */; };\n",
            "PBXBuildFile",
        )
        pbx = insert_once(
            pbx,
            "\t\tAB1001010000000000000004 /* AuthSessionModule.m */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.c.objc; name = AuthSessionModule.m; path = PocketPal/AuthSessionModule.m; sourceTree = \"<group>\"; };\n",
            "\t\tFB3000010000000000000003 /* FlipperBLEModule.swift */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; name = FlipperBLEModule.swift; path = PocketPal/FlipperBLEModule.swift; sourceTree = \"<group>\"; };\n"
            "\t\tFB3000010000000000000004 /* FlipperBLEModule.m */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.c.objc; name = FlipperBLEModule.m; path = PocketPal/FlipperBLEModule.m; sourceTree = \"<group>\"; };\n",
            "PBXFileReference",
        )
        pbx = insert_once(
            pbx,
            "\t\t\t\tAB1001010000000000000003 /* AuthSessionModule.swift */,\n",
            "\t\t\t\tFB3000010000000000000004 /* FlipperBLEModule.m */,\n"
            "\t\t\t\tFB3000010000000000000003 /* FlipperBLEModule.swift */,\n",
            "PBXGroup children",
        )
        pbx = insert_once(
            pbx,
            "\t\t\t\tAB1001010000000000000002 /* AuthSessionModule.m in Sources */,\n",
            "\t\t\t\tFB3000010000000000000001 /* FlipperBLEModule.swift in Sources */,\n"
            "\t\t\t\tFB3000010000000000000002 /* FlipperBLEModule.m in Sources */,\n",
            "PBXSourcesBuildPhase",
        )

    if "NSBluetoothAlwaysUsageDescription" not in plist:
        plist = insert_before_once(
            plist,
            "\t<key>NSCameraUsageDescription</key>\n",
            "\t<key>NSBluetoothAlwaysUsageDescription</key>\n"
            f"\t<string>{BLUETOOTH_USAGE}</string>\n",
            "Info.plist Bluetooth permission",
        )

    # Fail closed: never write a malformed plist.
    parsed_plist = plistlib.loads(plist.encode("utf-8"))
    if parsed_plist.get("NSBluetoothAlwaysUsageDescription") != BLUETOOTH_USAGE:
        raise RuntimeError("Info.plist Bluetooth permission did not survive plist parsing")

    # Only write after every requested transformation and validation succeeds.
    PBX.write_text(pbx)
    PLIST.write_text(plist)
    print("FLIPPER_IOS_PROJECT_PATCH_OK")
    print("FLIPPER_INFO_PLIST_VALID_OK")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"FLIPPER_IOS_PROJECT_PATCH_FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)

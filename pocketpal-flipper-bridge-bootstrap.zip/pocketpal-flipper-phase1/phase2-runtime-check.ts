import assert from 'node:assert/strict';
import {
  encodeDelimited,
  FlipperDelimitedStreamDecoder,
  FlipperFrameError,
} from './src/services/flipper/FlipperDelimitedStream';

const equal = (a: Uint8Array, b: Uint8Array) =>
  assert.deepEqual(Array.from(a), Array.from(b));

const payload = Uint8Array.from([8, 1, 42, 6, 10, 4, 0xde, 0xad, 0xbe, 0xef]);
const framed = encodeDelimited(payload);

for (let split = 0; split <= framed.length; split += 1) {
  const decoder = new FlipperDelimitedStreamDecoder();
  const frames = [
    ...decoder.push(framed.slice(0, split)),
    ...decoder.push(framed.slice(split)),
  ];
  assert.equal(frames.length, 1);
  equal(frames[0], payload);
  assert.equal(decoder.bufferedBytes, 0);
}

{
  const decoder = new FlipperDelimitedStreamDecoder();
  const frames: Uint8Array[] = [];
  for (const byte of framed) {
    frames.push(...decoder.push(Uint8Array.of(byte)));
  }
  assert.equal(frames.length, 1);
  equal(frames[0], payload);
}

{
  const large = new Uint8Array(300);
  for (let i = 0; i < large.length; i += 1) large[i] = i & 0xff;
  const frames = new FlipperDelimitedStreamDecoder().push(encodeDelimited(large));
  assert.equal(frames.length, 1);
  equal(frames[0], large);
}

{
  assert.throws(
    () =>
      new FlipperDelimitedStreamDecoder().push(
        Uint8Array.from([0xff, 0xff, 0xff, 0xff, 0x10]),
      ),
    FlipperFrameError,
  );
}

console.log('PHASE2_STREAM_RUNTIME_CHECK_OK');

import {FlipperStatusEngine} from '../FlipperStatusEngine';

describe('FlipperStatusEngine', () => {
  const engine = new FlipperStatusEngine();

  it('exposes the expected tool name', () => {
    expect(engine.name).toBe('flipper_status');
  });

  it('exposes a zero-argument OpenAI function schema', () => {
    const schema = engine.toToolDefinition();

    expect(schema.type).toBe('function');
    expect(schema.function.name).toBe('flipper_status');
    expect(schema.function.parameters).toEqual({
      type: 'object',
      properties: {},
      additionalProperties: false,
    });
  });

  it('returns deterministic mock status for the phase-1 transport boundary', async () => {
    const result = await engine.execute({});

    expect(result.type).toBe('text');
    if (result.type !== 'text') {
      throw new Error(`Unexpected result type: ${result.type}`);
    }

    expect(JSON.parse(result.summary)).toEqual({
      connected: true,
      device: 'MOCK_FLIPPER',
      firmware: 'MOCK',
      protobuf: '0.25',
      transport: 'mock',
    });
  });

  it('adds a prompt fragment that names the tool and blocks invented tools', () => {
    const fragment = engine.systemPromptFragment({
      now: new Date('2026-08-30T00:00:00Z'),
      maxToolTurns: 5,
      activeTalents: new Set(['flipper_status']),
    });

    expect(fragment).toContain('flipper_status');
    expect(fragment).toContain('Do not invent other Flipper tools');
  });
});

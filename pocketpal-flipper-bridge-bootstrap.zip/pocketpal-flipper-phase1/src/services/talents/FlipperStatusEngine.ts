import type {
  SystemPromptContext,
  TalentEngine,
  TalentResult,
  ToolDefinition,
} from './types';

/**
 * Phase-1 diagnostic Talent for the Flipper bridge.
 *
 * This intentionally contains no BLE/RPC code. Its only job is to prove the
 * PocketPal model -> AgentRunner -> Talent -> model loop before native hardware
 * transport is introduced.
 */
export class FlipperStatusEngine implements TalentEngine {
  readonly name = 'flipper_status';

  async execute(_args: Record<string, any>): Promise<TalentResult> {
    return {
      type: 'text',
      summary: JSON.stringify({
        connected: true,
        device: 'MOCK_FLIPPER',
        firmware: 'MOCK',
        protobuf: '0.25',
        transport: 'mock',
      }),
    };
  }

  toToolDefinition(): ToolDefinition {
    return {
      type: 'function',
      function: {
        name: this.name,
        description:
          'Check the connection and RPC status of the paired Flipper Zero. Use this when the user asks whether their Flipper is connected, reachable, ready, or what Flipper device/version is available.',
        parameters: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
      },
    };
  }

  systemPromptFragment(_ctx: SystemPromptContext): string {
    return [
      'Flipper Zero tool:',
      '- Use flipper_status when the user asks whether the Flipper is connected, reachable, ready, or asks for its status/version.',
      '- Do not invent other Flipper tools. Only call Flipper tools that are explicitly available.',
    ].join('\n');
  }
}

/** Canonical UUIDs used by the official Flipper iOS application. */
export const FLIPPER_BLE = Object.freeze({
  advertisedServices: ['3080', '3081', '3082', '3083'] as const,
  serialService: '8FE5B3D5-2E7F-4A98-2A48-7ACC60FE0000',
  serialRead: '19ED82AE-ED21-4C9D-4145-228E61FE0000',
  serialWrite: '19ED82AE-ED21-4C9D-4145-228E62FE0000',
  flowControl: '19ED82AE-ED21-4C9D-4145-228E63FE0000',
  restartSession: '19ED82AE-ED21-4C9D-4145-228E64FE0000',
});

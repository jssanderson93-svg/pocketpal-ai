const UINT32_VARINT_MAX_BYTES = 5;
const DEFAULT_MAX_FRAME_BYTES = 1024 * 1024;

export class FlipperFrameError extends Error {
  constructor(
    readonly code:
      | 'PROTOBUF_VARINT_INVALID'
      | 'PROTOBUF_FRAME_TOO_LARGE',
    message: string,
  ) {
    super(message);
    this.name = 'FlipperFrameError';
  }
}

function concatBytes(a: Uint8Array, b: Uint8Array): Uint8Array {
  if (a.length === 0) {
    return b.slice();
  }
  if (b.length === 0) {
    return a.slice();
  }

  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}

export function encodeVarint32(value: number): Uint8Array {
  if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) {
    throw new RangeError(`varint32 value out of range: ${value}`);
  }

  const bytes: number[] = [];
  let remaining = value >>> 0;
  do {
    let byte = remaining & 0x7f;
    remaining >>>= 7;
    if (remaining !== 0) {
      byte |= 0x80;
    }
    bytes.push(byte);
  } while (remaining !== 0);

  return Uint8Array.from(bytes);
}

export function encodeDelimited(payload: Uint8Array): Uint8Array {
  const prefix = encodeVarint32(payload.length);
  return concatBytes(prefix, payload);
}

interface ParsedPrefix {
  length: number;
  prefixBytes: number;
}

function parsePrefix(
  bytes: Uint8Array,
  maxFrameBytes: number,
): ParsedPrefix | null {
  let value = 0;
  let shift = 0;

  for (let i = 0; i < bytes.length && i < UINT32_VARINT_MAX_BYTES; i += 1) {
    const byte = bytes[i];

    // A uint32 varint may use five bytes, but on byte 5 only the low four bits
    // are valid. Anything above 0x0f would overflow 32 bits.
    if (i === 4 && (byte & 0xf0) !== 0) {
      throw new FlipperFrameError(
        'PROTOBUF_VARINT_INVALID',
        'Delimited protobuf length prefix overflows uint32',
      );
    }

    value += (byte & 0x7f) * 2 ** shift;

    if ((byte & 0x80) === 0) {
      if (value > maxFrameBytes) {
        throw new FlipperFrameError(
          'PROTOBUF_FRAME_TOO_LARGE',
          `Delimited protobuf frame ${value} bytes exceeds limit ${maxFrameBytes}`,
        );
      }

      return {length: value, prefixBytes: i + 1};
    }

    shift += 7;
  }

  if (bytes.length >= UINT32_VARINT_MAX_BYTES) {
    throw new FlipperFrameError(
      'PROTOBUF_VARINT_INVALID',
      'Delimited protobuf length prefix exceeds five bytes',
    );
  }

  return null;
}

/**
 * Reassembles protobuf `PB_ENCODE_DELIMITED` / `PB_DECODE_DELIMITED` byte
 * streams. BLE packet boundaries are intentionally ignored: callers may push
 * any fragmentation pattern and receive zero or more complete protobuf payloads.
 */
export class FlipperDelimitedStreamDecoder {
  private buffered = new Uint8Array(0);

  constructor(
    private readonly maxFrameBytes: number = DEFAULT_MAX_FRAME_BYTES,
  ) {
    if (!Number.isInteger(maxFrameBytes) || maxFrameBytes < 0) {
      throw new RangeError(`Invalid maxFrameBytes: ${maxFrameBytes}`);
    }
  }

  get bufferedBytes(): number {
    return this.buffered.length;
  }

  reset(): void {
    this.buffered = new Uint8Array(0);
  }

  push(chunk: Uint8Array): Uint8Array[] {
    if (!(chunk instanceof Uint8Array)) {
      throw new TypeError('FlipperDelimitedStreamDecoder.push expects Uint8Array');
    }

    this.buffered = concatBytes(this.buffered, chunk);
    const frames: Uint8Array[] = [];

    while (this.buffered.length > 0) {
      const prefix = parsePrefix(this.buffered, this.maxFrameBytes);
      if (!prefix) {
        break;
      }

      const frameEnd = prefix.prefixBytes + prefix.length;
      if (this.buffered.length < frameEnd) {
        break;
      }

      frames.push(this.buffered.slice(prefix.prefixBytes, frameEnd));
      this.buffered = this.buffered.slice(frameEnd);
    }

    return frames;
  }
}

import {
  encodeDelimited,
  FlipperDelimitedStreamDecoder,
  FlipperFrameError,
} from '../FlipperDelimitedStream';

function bytes(...values: number[]): Uint8Array {
  return Uint8Array.from(values);
}

function expectBytes(actual: Uint8Array, expected: Uint8Array): void {
  expect(Array.from(actual)).toEqual(Array.from(expected));
}

describe('FlipperDelimitedStreamDecoder', () => {
  const payload = bytes(
    0x08, 0x01, 0x2a, 0x06, 0x0a, 0x04, 0xde, 0xad, 0xbe, 0xef,
  );

  it('round-trips one complete delimited payload', () => {
    const decoder = new FlipperDelimitedStreamDecoder();
    const frames = decoder.push(encodeDelimited(payload));

    expect(frames).toHaveLength(1);
    expectBytes(frames[0], payload);
    expect(decoder.bufferedBytes).toBe(0);
  });

  it('survives every two-chunk split point', () => {
    const framed = encodeDelimited(payload);

    for (let split = 0; split <= framed.length; split += 1) {
      const decoder = new FlipperDelimitedStreamDecoder();
      const first = decoder.push(framed.slice(0, split));
      const second = decoder.push(framed.slice(split));
      const frames = [...first, ...second];

      expect(frames).toHaveLength(1);
      expectBytes(frames[0], payload);
      expect(decoder.bufferedBytes).toBe(0);
    }
  });

  it('survives one-byte-at-a-time fragmentation', () => {
    const decoder = new FlipperDelimitedStreamDecoder();
    const framed = encodeDelimited(payload);
    const frames: Uint8Array[] = [];

    for (const byte of framed) {
      frames.push(...decoder.push(bytes(byte)));
    }

    expect(frames).toHaveLength(1);
    expectBytes(frames[0], payload);
  });

  it('decodes several concatenated messages from one BLE chunk', () => {
    const a = encodeDelimited(bytes(1, 2, 3));
    const b = encodeDelimited(bytes(4));
    const c = encodeDelimited(bytes(5, 6));
    const combined = new Uint8Array(a.length + b.length + c.length);
    combined.set(a, 0);
    combined.set(b, a.length);
    combined.set(c, a.length + b.length);

    const frames = new FlipperDelimitedStreamDecoder().push(combined);

    expect(frames.map(frame => Array.from(frame))).toEqual([
      [1, 2, 3],
      [4],
      [5, 6],
    ]);
  });

  it('retains an incomplete trailing message after returning earlier frames', () => {
    const first = encodeDelimited(bytes(10, 11));
    const second = encodeDelimited(bytes(12, 13, 14));
    const partialSecond = second.slice(0, second.length - 1);
    const chunk = new Uint8Array(first.length + partialSecond.length);
    chunk.set(first, 0);
    chunk.set(partialSecond, first.length);

    const decoder = new FlipperDelimitedStreamDecoder();
    const frames = decoder.push(chunk);

    expect(frames).toHaveLength(1);
    expectBytes(frames[0], bytes(10, 11));
    expect(decoder.bufferedBytes).toBe(partialSecond.length);

    const finalFrames = decoder.push(second.slice(second.length - 1));
    expect(finalFrames).toHaveLength(1);
    expectBytes(finalFrames[0], bytes(12, 13, 14));
    expect(decoder.bufferedBytes).toBe(0);
  });

  it('supports multi-byte length prefixes', () => {
    const large = new Uint8Array(300);
    for (let i = 0; i < large.length; i += 1) {
      large[i] = i & 0xff;
    }

    const decoder = new FlipperDelimitedStreamDecoder();
    const frames = decoder.push(encodeDelimited(large));

    expect(frames).toHaveLength(1);
    expectBytes(frames[0], large);
  });

  it('rejects a uint32-overflowing length prefix', () => {
    const decoder = new FlipperDelimitedStreamDecoder();

    expect(() => decoder.push(bytes(0xff, 0xff, 0xff, 0xff, 0x10))).toThrow(
      FlipperFrameError,
    );
  });

  it('rejects a length prefix longer than five bytes', () => {
    const decoder = new FlipperDelimitedStreamDecoder();

    expect(() => decoder.push(bytes(0x80, 0x80, 0x80, 0x80, 0x80))).toThrow(
      FlipperFrameError,
    );
  });

  it('rejects frames beyond the configured maximum before buffering the body', () => {
    const decoder = new FlipperDelimitedStreamDecoder(16);

    expect(() => decoder.push(bytes(17))).toThrow(FlipperFrameError);
  });

  it('reset discards partial state', () => {
    const decoder = new FlipperDelimitedStreamDecoder();
    const framed = encodeDelimited(payload);

    decoder.push(framed.slice(0, 3));
    expect(decoder.bufferedBytes).toBeGreaterThan(0);

    decoder.reset();
    expect(decoder.bufferedBytes).toBe(0);
  });
});

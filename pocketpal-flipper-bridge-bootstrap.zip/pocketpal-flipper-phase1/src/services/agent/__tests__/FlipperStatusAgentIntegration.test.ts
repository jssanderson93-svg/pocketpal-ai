import {runAgent} from '../AgentRunner';
import type {AgentEvent} from '../AgentRunner.types';
import type {
  ApiCompletionParams,
  CompletionEngine,
  CompletionResult,
  CompletionStreamData,
} from '../../../utils/completionTypes';
import {FlipperStatusEngine} from '../../talents/FlipperStatusEngine';

async function collect(iter: AsyncIterable<AgentEvent>): Promise<AgentEvent[]> {
  const out: AgentEvent[] = [];
  for await (const event of iter) {
    out.push(event);
  }
  return out;
}

describe('FlipperStatusEngine + AgentRunner', () => {
  it('executes flipper_status and feeds its result into the next model turn', async () => {
    const calls: ApiCompletionParams[] = [];
    let turn = 0;

    const engine: CompletionEngine = {
      completion: jest.fn(
        async (
          params: ApiCompletionParams,
          cb?: (data: CompletionStreamData) => void,
        ): Promise<CompletionResult> => {
          calls.push(params);
          turn += 1;

          if (turn === 1) {
            return {
              text: '',
              content: '',
              tool_calls: [
                {
                  id: 'flipper-call-1',
                  type: 'function',
                  function: {
                    name: 'flipper_status',
                    arguments: '{}',
                  },
                },
              ],
            } as CompletionResult;
          }

          cb?.({content: 'The Flipper is reachable.'});
          return {
            text: 'The Flipper is reachable.',
            content: 'The Flipper is reachable.',
          } as CompletionResult;
        },
      ),
      stopCompletion: jest.fn(async () => {}),
    };

    const flipperStatus = new FlipperStatusEngine();
    const events = await collect(
      runAgent({
        engine,
        initialParams: {messages: []} as ApiCompletionParams,
        allowedTalentNames: ['flipper_status'],
        talentLookup: name =>
          name === 'flipper_status' ? flipperStatus : undefined,
        messageId: 'phase-1-flipper-test',
        triggerMarkers: [],
      }),
    );

    const toolFinished = events.find(e => e.type === 'tool_call_finished');
    expect(toolFinished).toBeDefined();
    if (!toolFinished || toolFinished.type !== 'tool_call_finished') {
      throw new Error('Expected tool_call_finished event');
    }

    expect(toolFinished.outcome.toolName).toBe('flipper_status');
    expect(JSON.parse(toolFinished.outcome.responseContent)).toMatchObject({
      connected: true,
      device: 'MOCK_FLIPPER',
      transport: 'mock',
    });

    expect(calls).toHaveLength(2);
    const secondTurnMessages = calls[1].messages ?? [];
    const toolMessage = secondTurnMessages.find(
      (message: any) => message.role === 'tool',
    ) as any;

    expect(toolMessage).toBeDefined();
    expect(toolMessage.tool_call_id).toBe('flipper-call-1');
    expect(JSON.parse(toolMessage.content)).toMatchObject({
      connected: true,
      device: 'MOCK_FLIPPER',
      protobuf: '0.25',
    });
  });
});

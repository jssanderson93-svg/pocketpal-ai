import type {TurboModule} from 'react-native';
import {TurboModuleRegistry} from 'react-native';

export interface FlipperPeripheralSummary {
  identifier: string;
  name: string;
  rssi: number;
  advertisedService?: string;
}

export interface FlipperCharacteristicFingerprint {
  uuid: string;
  properties: string[];
  isNotifying: boolean;
}

export interface FlipperGattFingerprint {
  identifier: string;
  name: string;
  serialService: string;
  serialRead: FlipperCharacteristicFingerprint;
  serialWrite: FlipperCharacteristicFingerprint;
  flowControl: FlipperCharacteristicFingerprint;
  restartSession: FlipperCharacteristicFingerprint;
  flowControlFreeBytes: number;
  maxWriteWithResponse: number;
  maxWriteWithoutResponse: number;
}

export interface FlipperBLEState {
  state: string;
  authorization: string;
  isScanning: boolean;
  connectedIdentifier?: string;
  flowControlFreeBytes: number;
}

export interface Spec extends TurboModule {
  getState(): Promise<FlipperBLEState>;
  scan(timeoutMs: number): Promise<FlipperPeripheralSummary[]>;
  connect(identifier: string, timeoutMs: number): Promise<FlipperGattFingerprint>;
  disconnect(): Promise<void>;
  restartRpcSession(): Promise<void>;
  getGattFingerprint(): Promise<FlipperGattFingerprint>;
}

export default TurboModuleRegistry.get<Spec>('FlipperBLEModule');

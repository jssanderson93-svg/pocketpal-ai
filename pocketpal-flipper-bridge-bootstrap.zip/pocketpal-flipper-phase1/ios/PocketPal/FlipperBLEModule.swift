import Foundation
import CoreBluetooth
import React

@objc(FlipperBLEModule)
final class FlipperBLEModule: NSObject, RCTBridgeModule {
    private static let advertisedServices = ["3080", "3081", "3082", "3083"].map(CBUUID.init(string:))
    private static let serialServiceUUID = CBUUID(string: "8FE5B3D5-2E7F-4A98-2A48-7ACC60FE0000")
    private static let serialReadUUID = CBUUID(string: "19ED82AE-ED21-4C9D-4145-228E61FE0000")
    private static let serialWriteUUID = CBUUID(string: "19ED82AE-ED21-4C9D-4145-228E62FE0000")
    private static let flowControlUUID = CBUUID(string: "19ED82AE-ED21-4C9D-4145-228E63FE0000")
    private static let restartSessionUUID = CBUUID(string: "19ED82AE-ED21-4C9D-4145-228E64FE0000")

    private var central: CBCentralManager!
    private var discovered: [UUID: (peripheral: CBPeripheral, rssi: Int, advertisedService: String?)] = [:]
    private var activePeripheral: CBPeripheral?

    private var serialRead: CBCharacteristic?
    private var serialWrite: CBCharacteristic?
    private var flowControl: CBCharacteristic?
    private var restartSession: CBCharacteristic?
    private var flowControlFreeBytes = 0
    private var notificationReady = Set<CBUUID>()

    private var scanResolve: RCTPromiseResolveBlock?
    private var scanReject: RCTPromiseRejectBlock?
    private var scanTimeout: DispatchWorkItem?

    private var connectResolve: RCTPromiseResolveBlock?
    private var connectReject: RCTPromiseRejectBlock?
    private var connectTimeout: DispatchWorkItem?

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: DispatchQueue.main)
    }

    @objc
    static func moduleName() -> String! {
        "FlipperBLEModule"
    }

    @objc
    static func requiresMainQueueSetup() -> Bool {
        true
    }

    @objc
    func getState(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            resolve(self.statePayload())
        }
    }

    @objc
    func scan(
        _ timeoutMs: NSNumber,
        resolver resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            guard self.central.state == .poweredOn else {
                reject(self.centralStateErrorCode(), "Bluetooth is not powered on", nil)
                return
            }
            guard self.scanResolve == nil else {
                reject("BLE_SCAN_ALREADY_RUNNING", "A Flipper BLE scan is already running", nil)
                return
            }

            let timeout = max(250, timeoutMs.intValue)
            self.discovered.removeAll()
            self.scanResolve = resolve
            self.scanReject = reject
            self.central.scanForPeripherals(
                withServices: Self.advertisedServices,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
            )

            let work = DispatchWorkItem { [weak self] in
                self?.finishScan()
            }
            self.scanTimeout = work
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(timeout), execute: work)
        }
    }

    @objc
    func connect(
        _ identifier: String,
        timeoutMs: NSNumber,
        resolver resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            guard self.central.state == .poweredOn else {
                reject(self.centralStateErrorCode(), "Bluetooth is not powered on", nil)
                return
            }
            guard self.connectResolve == nil else {
                reject("BLE_CONNECT_ALREADY_RUNNING", "A Flipper connection attempt is already running", nil)
                return
            }
            guard let uuid = UUID(uuidString: identifier) else {
                reject("BLE_IDENTIFIER_INVALID", "Invalid peripheral identifier", nil)
                return
            }

            let peripheral = self.discovered[uuid]?.peripheral
                ?? self.central.retrievePeripherals(withIdentifiers: [uuid]).first
            guard let peripheral else {
                reject("BLE_PERIPHERAL_NOT_FOUND", "Peripheral is not available to CoreBluetooth", nil)
                return
            }

            self.clearGattState()
            self.connectResolve = resolve
            self.connectReject = reject
            self.activePeripheral = peripheral
            peripheral.delegate = self

            let timeout = max(1_000, timeoutMs.intValue)
            let work = DispatchWorkItem { [weak self] in
                self?.failConnect(
                    code: "BLE_CONNECT_TIMEOUT",
                    message: "Timed out before Flipper serial GATT became ready",
                    error: nil
                )
            }
            self.connectTimeout = work
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(timeout), execute: work)

            self.central.connect(peripheral, options: nil)
        }
    }

    @objc
    func disconnect(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            self.cancelPendingConnect(code: "BLE_CONNECT_CANCELLED", message: "Connection cancelled")
            if let peripheral = self.activePeripheral {
                self.central.cancelPeripheralConnection(peripheral)
            }
            self.activePeripheral = nil
            self.clearGattState()
            resolve(nil)
        }
    }

    @objc
    func restartRpcSession(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            guard let peripheral = self.activePeripheral,
                  peripheral.state == .connected,
                  let restart = self.restartSession else {
                reject("RPC_RESTART_UNAVAILABLE", "Flipper restart-session characteristic is not ready", nil)
                return
            }
            peripheral.writeValue(Data([0]), for: restart, type: .withResponse)
            resolve(nil)
        }
    }

    @objc
    func getGattFingerprint(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async {
            guard let fingerprint = self.makeGattFingerprint() else {
                reject("GATT_NOT_READY", "Flipper serial GATT fingerprint is not complete", nil)
                return
            }
            resolve(fingerprint)
        }
    }

    private func finishScan() {
        guard let resolve = scanResolve else { return }
        central.stopScan()
        scanTimeout?.cancel()
        scanTimeout = nil
        scanResolve = nil
        scanReject = nil

        let result: [[String: Any]] = discovered.values
            .map { entry in
                var value: [String: Any] = [
                    "identifier": entry.peripheral.identifier.uuidString,
                    "name": entry.peripheral.name ?? "Unknown",
                    "rssi": entry.rssi,
                ]
                if let service = entry.advertisedService {
                    value["advertisedService"] = service
                }
                return value
            }
            .sorted { ($0["rssi"] as? Int ?? -999) > ($1["rssi"] as? Int ?? -999) }

        resolve(result)
    }

    private func completeConnectIfReady() {
        guard connectResolve != nil else { return }
        guard serialRead != nil,
              serialWrite != nil,
              flowControl != nil,
              restartSession != nil,
              notificationReady.contains(Self.serialReadUUID),
              notificationReady.contains(Self.flowControlUUID),
              let fingerprint = makeGattFingerprint() else {
            return
        }

        let resolve = connectResolve
        connectResolve = nil
        connectReject = nil
        connectTimeout?.cancel()
        connectTimeout = nil
        resolve?(fingerprint)
    }

    private func failConnect(code: String, message: String, error: Error?) {
        guard let reject = connectReject else { return }
        connectResolve = nil
        connectReject = nil
        connectTimeout?.cancel()
        connectTimeout = nil
        reject(code, message, error)
    }

    private func cancelPendingConnect(code: String, message: String) {
        if connectReject != nil {
            failConnect(code: code, message: message, error: nil)
        }
    }

    private func clearGattState() {
        serialRead = nil
        serialWrite = nil
        flowControl = nil
        restartSession = nil
        flowControlFreeBytes = 0
        notificationReady.removeAll()
    }

    private func statePayload() -> [String: Any] {
        var result: [String: Any] = [
            "state": centralStateName(central.state),
            "authorization": authorizationName(CBManager.authorization),
            "isScanning": central.isScanning,
            "flowControlFreeBytes": flowControlFreeBytes,
        ]
        if let activePeripheral {
            result["connectedIdentifier"] = activePeripheral.identifier.uuidString
        }
        return result
    }

    private func makeGattFingerprint() -> [String: Any]? {
        guard let peripheral = activePeripheral,
              let serialRead,
              let serialWrite,
              let flowControl,
              let restartSession else {
            return nil
        }

        return [
            "identifier": peripheral.identifier.uuidString,
            "name": peripheral.name ?? "Unknown",
            "serialService": Self.serialServiceUUID.uuidString,
            "serialRead": characteristicPayload(serialRead),
            "serialWrite": characteristicPayload(serialWrite),
            "flowControl": characteristicPayload(flowControl),
            "restartSession": characteristicPayload(restartSession),
            "flowControlFreeBytes": flowControlFreeBytes,
            "maxWriteWithResponse": peripheral.maximumWriteValueLength(for: .withResponse),
            "maxWriteWithoutResponse": peripheral.maximumWriteValueLength(for: .withoutResponse),
        ]
    }

    private func characteristicPayload(_ characteristic: CBCharacteristic) -> [String: Any] {
        [
            "uuid": characteristic.uuid.uuidString,
            "properties": propertyNames(characteristic.properties),
            "isNotifying": characteristic.isNotifying,
        ]
    }

    private func propertyNames(_ properties: CBCharacteristicProperties) -> [String] {
        var names: [String] = []
        if properties.contains(.broadcast) { names.append("broadcast") }
        if properties.contains(.read) { names.append("read") }
        if properties.contains(.writeWithoutResponse) { names.append("writeWithoutResponse") }
        if properties.contains(.write) { names.append("write") }
        if properties.contains(.notify) { names.append("notify") }
        if properties.contains(.indicate) { names.append("indicate") }
        if properties.contains(.authenticatedSignedWrites) { names.append("authenticatedSignedWrites") }
        if properties.contains(.extendedProperties) { names.append("extendedProperties") }
        if properties.contains(.notifyEncryptionRequired) { names.append("notifyEncryptionRequired") }
        if properties.contains(.indicateEncryptionRequired) { names.append("indicateEncryptionRequired") }
        return names
    }

    private func centralStateErrorCode() -> String {
        switch central.state {
        case .poweredOff: return "BLE_POWERED_OFF"
        case .unauthorized: return "BLE_UNAUTHORIZED"
        case .unsupported: return "BLE_UNSUPPORTED"
        case .resetting: return "BLE_RESETTING"
        case .unknown: return "BLE_STATE_UNKNOWN"
        case .poweredOn: return "BLE_READY"
        @unknown default: return "BLE_STATE_UNKNOWN"
        }
    }

    private func centralStateName(_ state: CBManagerState) -> String {
        switch state {
        case .unknown: return "unknown"
        case .resetting: return "resetting"
        case .unsupported: return "unsupported"
        case .unauthorized: return "unauthorized"
        case .poweredOff: return "poweredOff"
        case .poweredOn: return "poweredOn"
        @unknown default: return "unknown"
        }
    }

    private func authorizationName(_ authorization: CBManagerAuthorization) -> String {
        switch authorization {
        case .notDetermined: return "notDetermined"
        case .restricted: return "restricted"
        case .denied: return "denied"
        case .allowedAlways: return "allowedAlways"
        @unknown default: return "unknown"
        }
    }

    private func rejectForPeripheralError(_ error: Error) {
        if let attError = error as? CBATTError, attError.code == .insufficientEncryption {
            failConnect(
                code: "AUTHENTICATION_FAILED",
                message: "Flipper serial service requires an authenticated Bluetooth bond",
                error: error
            )
        } else {
            failConnect(code: "GATT_ERROR", message: error.localizedDescription, error: error)
        }
    }

    private func decodeBigEndianUInt32(_ data: Data) -> Int? {
        guard data.count >= 4 else { return nil }
        let bytes = [UInt8](data.prefix(4))
        return Int(UInt32(bytes[0]) << 24 |
                   UInt32(bytes[1]) << 16 |
                   UInt32(bytes[2]) << 8 |
                   UInt32(bytes[3]))
    }
}

extension FlipperBLEModule: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state != .poweredOn {
            if scanResolve != nil {
                scanTimeout?.cancel()
                scanTimeout = nil
                scanResolve = nil
                let reject = scanReject
                scanReject = nil
                reject?(centralStateErrorCode(), "Bluetooth became unavailable", nil)
            }
            cancelPendingConnect(code: centralStateErrorCode(), message: "Bluetooth became unavailable")
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        let advertised = (advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID])?
            .first(where: { Self.advertisedServices.contains($0) })?
            .uuidString
        discovered[peripheral.identifier] = (peripheral, RSSI.intValue, advertised)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        activePeripheral = peripheral
        peripheral.discoverServices([Self.serialServiceUUID])
    }

    func centralManager(
        _ central: CBCentralManager,
        didFailToConnect peripheral: CBPeripheral,
        error: Error?
    ) {
        failConnect(
            code: "BLE_CONNECT_FAILED",
            message: error?.localizedDescription ?? "CoreBluetooth failed to connect",
            error: error
        )
    }

    func centralManager(
        _ central: CBCentralManager,
        didDisconnectPeripheral peripheral: CBPeripheral,
        error: Error?
    ) {
        if activePeripheral?.identifier == peripheral.identifier {
            activePeripheral = nil
            clearGattState()
        }
        if connectReject != nil {
            failConnect(
                code: "BLE_DISCONNECTED_DURING_SETUP",
                message: error?.localizedDescription ?? "Flipper disconnected before GATT became ready",
                error: error
            )
        }
    }
}

extension FlipperBLEModule: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error {
            rejectForPeripheralError(error)
            return
        }
        guard let service = peripheral.services?.first(where: { $0.uuid == Self.serialServiceUUID }) else {
            failConnect(
                code: "SERIAL_SERVICE_MISSING",
                message: "Expected Flipper serial service was not discovered",
                error: nil
            )
            return
        }
        peripheral.discoverCharacteristics(
            [
                Self.serialReadUUID,
                Self.serialWriteUUID,
                Self.flowControlUUID,
                Self.restartSessionUUID,
            ],
            for: service
        )
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didDiscoverCharacteristicsFor service: CBService,
        error: Error?
    ) {
        if let error {
            rejectForPeripheralError(error)
            return
        }
        guard service.uuid == Self.serialServiceUUID else { return }
        let characteristics = service.characteristics ?? []

        serialRead = characteristics.first(where: { $0.uuid == Self.serialReadUUID })
        serialWrite = characteristics.first(where: { $0.uuid == Self.serialWriteUUID })
        flowControl = characteristics.first(where: { $0.uuid == Self.flowControlUUID })
        restartSession = characteristics.first(where: { $0.uuid == Self.restartSessionUUID })

        guard let serialRead else {
            failConnect(code: "SERIAL_READ_MISSING", message: "61FE serial-read characteristic missing", error: nil)
            return
        }
        guard let flowControl else {
            failConnect(code: "FLOW_CONTROL_MISSING", message: "63FE flow-control characteristic missing", error: nil)
            return
        }
        guard let serialWrite else {
            failConnect(code: "SERIAL_WRITE_MISSING", message: "62FE serial-write characteristic missing", error: nil)
            return
        }
        guard let restartSession else {
            failConnect(code: "RPC_STATUS_MISSING", message: "64FE RPC-status characteristic missing", error: nil)
            return
        }

        let expected: [(CBCharacteristic, CBCharacteristicProperties, String)] = [
            (serialRead, [.read, .indicate], "61FE serial-read"),
            (serialWrite, [.read, .write, .writeWithoutResponse], "62FE serial-write"),
            (flowControl, [.read, .notify], "63FE flow-control"),
            (restartSession, [.read, .write, .notify], "64FE RPC-status"),
        ]
        for (characteristic, required, label) in expected {
            guard characteristic.properties.contains(required) else {
                failConnect(
                    code: "GATT_PROPERTY_MISMATCH",
                    message: "\(label) properties were \(propertyNames(characteristic.properties)); required \(propertyNames(required))",
                    error: nil
                )
                return
            }
        }

        peripheral.setNotifyValue(true, for: serialRead)
        peripheral.setNotifyValue(true, for: flowControl)
        peripheral.readValue(for: flowControl)
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateNotificationStateFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            rejectForPeripheralError(error)
            return
        }
        if characteristic.isNotifying {
            notificationReady.insert(characteristic.uuid)
        }
        completeConnectIfReady()
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateValueFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            rejectForPeripheralError(error)
            return
        }
        if characteristic.uuid == Self.flowControlUUID,
           let value = characteristic.value,
           let freeBytes = decodeBigEndianUInt32(value) {
            flowControlFreeBytes = freeBytes
        }
    }
}

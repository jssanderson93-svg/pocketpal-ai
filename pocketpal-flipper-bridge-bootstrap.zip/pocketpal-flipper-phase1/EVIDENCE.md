# Evidence ledger

## PocketPal base

- Repository: https://github.com/a-ghorbani/pocketpal-ai
- Base commit: `ed680864adea0b090dac173b27675987c000fef2`
- `TalentEngine` contract: `src/services/talents/types.ts`
- Built-in Talent registration: `src/services/talents/index.ts`
- Agent tool loop: `src/services/agent/AgentRunner.ts`
- Existing Swift/Objective-C React Native module pattern: `AuthSessionModule.swift`, `AuthSessionModule.m`, `src/specs/NativeAuthSession.ts`

## Flipper protobuf

- Repository: https://github.com/flipperdevices/flipperzero-protobuf
- Pinned dev commit inspected: `1c84fa48919cbb71d1cc65236fc0ee36740e24c6`
- `flipper.proto` SHA: `2ba75dadce34aebe41a325e6038fcde21ee79fa0`
- `PB.Main` fields include `command_id`, `command_status`, `has_next`, and the typed oneof RPC payloads.

## Flipper firmware RPC framing

- Repository: https://github.com/flipperdevices/flipperzero-firmware
- Firmware source ref inspected: `9b7ccb3fd3cd88c7adb2ab2f49909e4a7b3bc56b`
- `applications/services/rpc/rpc.c` SHA: `1a19348ffcd2b32b3e61b6e5e1dbe0c8afc7e621`
- Server decodes with `PB_DECODE_DELIMITED`.
- Server encodes with `PB_ENCODE_DELIMITED`.
- A framing/decode failure resets the RPC stream and, for BLE-owned RPC, restores the default BT profile/disconnects the BLE session.

## Flipper BLE UUIDs and iOS behavior

Official iOS app repository:
https://github.com/flipperdevices/Flipper-iOS-App

Reference inspected: `fa45704a81c3d4820838e1f2604a5862a5e63a1e`

`CBUUID.swift` SHA: `f1174de2b240ac0b5937bb27f1c9a843448aa055`

Canonical CoreBluetooth UUIDs:

- advertised IDs: `3080`, `3081`, `3082`, `3083`
- serial service: `8FE5B3D5-2E7F-4A98-2A48-7ACC60FE0000`
- serial read / Flipper -> iPhone: `19ED82AE-ED21-4C9D-4145-228E61FE0000`
- serial write / iPhone -> Flipper: `19ED82AE-ED21-4C9D-4145-228E62FE0000`
- flow control: `19ED82AE-ED21-4C9D-4145-228E63FE0000`
- RPC restart/status: `19ED82AE-ED21-4C9D-4145-228E64FE0000`

`FlipperPeripheral.swift` SHA: `eb5746c2ae30edb7094473b24e8913b1962d7d6c`

Official app behavior copied into this bootstrap:

- subscribe to serial-read and flow-control
- read flow-control immediately
- decode flow-control as big-endian Int32
- cap available write length by flow-control free space and CoreBluetooth maximum
- use `.withResponse` for serial writes
- write `[0]` to restart-session characteristic to request session restart

`FlipperCentral.swift` SHA: `e6777cb9aaeb6bc6ab90e93896bb6476c53a4058`

Official app scans using the advertised Flipper service IDs rather than the full serial service UUID.

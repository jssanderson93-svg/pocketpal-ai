"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FlipperDelimitedStreamDecoder = exports.FlipperFrameError = void 0;
exports.encodeVarint32 = encodeVarint32;
exports.encodeDelimited = encodeDelimited;
const UINT32_VARINT_MAX_BYTES = 5;
const DEFAULT_MAX_FRAME_BYTES = 1024 * 1024;
class FlipperFrameError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'FlipperFrameError';
    }
}
exports.FlipperFrameError = FlipperFrameError;
function concatBytes(a, b) {
    if (a.length === 0) {
        return b.slice();
    }
    if (b.length === 0) {
        return a.slice();
    }
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
}
function encodeVarint32(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) {
        throw new RangeError(`varint32 value out of range: ${value}`);
    }
    const bytes = [];
    let remaining = value >>> 0;
    do {
        let byte = remaining & 0x7f;
        remaining >>>= 7;
        if (remaining !== 0) {
            byte |= 0x80;
        }
        bytes.push(byte);
    } while (remaining !== 0);
    return Uint8Array.from(bytes);
}
function encodeDelimited(payload) {
    const prefix = encodeVarint32(payload.length);
    return concatBytes(prefix, payload);
}
function parsePrefix(bytes, maxFrameBytes) {
    let value = 0;
    let shift = 0;
    for (let i = 0; i < bytes.length && i < UINT32_VARINT_MAX_BYTES; i += 1) {
        const byte = bytes[i];
        // A uint32 varint may use five bytes, but on byte 5 only the low four bits
        // are valid. Anything above 0x0f would overflow 32 bits.
        if (i === 4 && (byte & 0xf0) !== 0) {
            throw new FlipperFrameError('PROTOBUF_VARINT_INVALID', 'Delimited protobuf length prefix overflows uint32');
        }
        value += (byte & 0x7f) * 2 ** shift;
        if ((byte & 0x80) === 0) {
            if (value > maxFrameBytes) {
                throw new FlipperFrameError('PROTOBUF_FRAME_TOO_LARGE', `Delimited protobuf frame ${value} bytes exceeds limit ${maxFrameBytes}`);
            }
            return { length: value, prefixBytes: i + 1 };
        }
        shift += 7;
    }
    if (bytes.length >= UINT32_VARINT_MAX_BYTES) {
        throw new FlipperFrameError('PROTOBUF_VARINT_INVALID', 'Delimited protobuf length prefix exceeds five bytes');
    }
    return null;
}
/**
 * Reassembles protobuf `PB_ENCODE_DELIMITED` / `PB_DECODE_DELIMITED` byte
 * streams. BLE packet boundaries are intentionally ignored: callers may push
 * any fragmentation pattern and receive zero or more complete protobuf payloads.
 */
class FlipperDelimitedStreamDecoder {
    constructor(maxFrameBytes = DEFAULT_MAX_FRAME_BYTES) {
        this.maxFrameBytes = maxFrameBytes;
        this.buffered = new Uint8Array(0);
        if (!Number.isInteger(maxFrameBytes) || maxFrameBytes < 0) {
            throw new RangeError(`Invalid maxFrameBytes: ${maxFrameBytes}`);
        }
    }
    get bufferedBytes() {
        return this.buffered.length;
    }
    reset() {
        this.buffered = new Uint8Array(0);
    }
    push(chunk) {
        if (!(chunk instanceof Uint8Array)) {
            throw new TypeError('FlipperDelimitedStreamDecoder.push expects Uint8Array');
        }
        this.buffered = concatBytes(this.buffered, chunk);
        const frames = [];
        while (this.buffered.length > 0) {
            const prefix = parsePrefix(this.buffered, this.maxFrameBytes);
            if (!prefix) {
                break;
            }
            const frameEnd = prefix.prefixBytes + prefix.length;
            if (this.buffered.length < frameEnd) {
                break;
            }
            frames.push(this.buffered.slice(prefix.prefixBytes, frameEnd));
            this.buffered = this.buffered.slice(frameEnd);
        }
        return frames;
    }
}
exports.FlipperDelimitedStreamDecoder = FlipperDelimitedStreamDecoder;

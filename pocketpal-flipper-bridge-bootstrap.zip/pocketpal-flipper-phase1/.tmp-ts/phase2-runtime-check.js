"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const FlipperDelimitedStream_1 = require("./src/services/flipper/FlipperDelimitedStream");
const equal = (a, b) => strict_1.default.deepEqual(Array.from(a), Array.from(b));
const payload = Uint8Array.from([8, 1, 42, 6, 10, 4, 0xde, 0xad, 0xbe, 0xef]);
const framed = (0, FlipperDelimitedStream_1.encodeDelimited)(payload);
for (let split = 0; split <= framed.length; split += 1) {
    const decoder = new FlipperDelimitedStream_1.FlipperDelimitedStreamDecoder();
    const frames = [
        ...decoder.push(framed.slice(0, split)),
        ...decoder.push(framed.slice(split)),
    ];
    strict_1.default.equal(frames.length, 1);
    equal(frames[0], payload);
    strict_1.default.equal(decoder.bufferedBytes, 0);
}
{
    const decoder = new FlipperDelimitedStream_1.FlipperDelimitedStreamDecoder();
    const frames = [];
    for (const byte of framed) {
        frames.push(...decoder.push(Uint8Array.of(byte)));
    }
    strict_1.default.equal(frames.length, 1);
    equal(frames[0], payload);
}
{
    const large = new Uint8Array(300);
    for (let i = 0; i < large.length; i += 1)
        large[i] = i & 0xff;
    const frames = new FlipperDelimitedStream_1.FlipperDelimitedStreamDecoder().push((0, FlipperDelimitedStream_1.encodeDelimited)(large));
    strict_1.default.equal(frames.length, 1);
    equal(frames[0], large);
}
{
    strict_1.default.throws(() => new FlipperDelimitedStream_1.FlipperDelimitedStreamDecoder().push(Uint8Array.from([0xff, 0xff, 0xff, 0xff, 0x10])), FlipperDelimitedStream_1.FlipperFrameError);
}
console.log('PHASE2_STREAM_RUNTIME_CHECK_OK');

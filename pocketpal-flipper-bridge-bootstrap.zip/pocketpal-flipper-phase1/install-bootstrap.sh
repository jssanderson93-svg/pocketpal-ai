#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f package.json || ! -d src/services/talents || ! -d ios/PocketPal ]]; then
  echo "ERROR: run this from the root of a PocketPal checkout" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_BASE="ed680864adea0b090dac173b27675987c000fef2"
CURRENT_HEAD="$(git rev-parse HEAD 2>/dev/null || true)"

if [[ "$CURRENT_HEAD" != "$EXPECTED_BASE" ]]; then
  echo "ERROR: expected PocketPal base $EXPECTED_BASE, got ${CURRENT_HEAD:-unknown}" >&2
  echo "Refusing to patch an unverified source tree." >&2
  exit 1
fi

if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "ERROR: PocketPal checkout has local changes; refusing to mix them with the bootstrap." >&2
  exit 1
fi

git apply --check "$SCRIPT_DIR/phase1-flipper-status.patch"
git apply "$SCRIPT_DIR/phase1-flipper-status.patch"

mkdir -p src/services/flipper src/specs ios/PocketPal scripts
cp -R "$SCRIPT_DIR/src/services/flipper/." src/services/flipper/
cp "$SCRIPT_DIR/src/specs/NativeFlipperBLE.ts" src/specs/NativeFlipperBLE.ts
cp "$SCRIPT_DIR/ios/PocketPal/FlipperBLEModule.swift" ios/PocketPal/FlipperBLEModule.swift
cp "$SCRIPT_DIR/ios/PocketPal/FlipperBLEModule.m" ios/PocketPal/FlipperBLEModule.m
cp "$SCRIPT_DIR/scripts/patch-pocketpal-ios-project.py" scripts/patch-pocketpal-ios-project.py
chmod +x scripts/patch-pocketpal-ios-project.py
python3 scripts/patch-pocketpal-ios-project.py

echo "BOOTSTRAP_APPLIED_OK"
echo "Next quality gates: yarn lint && yarn typecheck && yarn test"

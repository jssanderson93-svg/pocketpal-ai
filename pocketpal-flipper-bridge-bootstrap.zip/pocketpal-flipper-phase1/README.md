# PocketPal ↔ Flipper Zero bridge bootstrap

This package implements the first three gates of the integration while keeping each failure attributable to one layer.

## Verified base

PocketPal commit:

`ed680864adea0b090dac173b27675987c000fef2`

## Included

### Gate 1 — PocketPal agent path

- `FlipperStatusEngine.ts`: deterministic mock `flipper_status` Talent.
- direct Talent tests.
- AgentRunner integration test proving the tool result is returned to the model on the next turn.
- `phase1-flipper-status.patch`: adds the Talent to PocketPal's built-in registry.

### Gate 2 — RPC stream framing

- `FlipperDelimitedStream.ts`: dependency-free `PB_ENCODE_DELIMITED` / `PB_DECODE_DELIMITED` framing layer.
- fragmentation tests, malformed-varint rejection, frame-size limit, concatenated-frame handling.
- standalone runtime check.

### Gate 3 — iOS BLE/GATT diagnostics

- `NativeFlipperBLE.ts`: typed React Native contract.
- `FlipperBLEModule.swift` + Objective-C bridge.
- scan filtered to the official advertised Flipper service IDs `3080–3083`.
- exact official serial/read/write/flow/restart UUIDs.
- GATT property validation.
- flow-control decoding as big-endian UInt32.
- explicit diagnostic error codes.
- `restartRpcSession()` using the same `[0]` write used by Flipper's official iOS app.
- fail-closed Xcode project + Bluetooth permission patch script.

## Apply to PocketPal

Copy this package beside a clean PocketPal checkout, then from the PocketPal root run:

```bash
/path/to/pocketpal-flipper-phase1/install-bootstrap.sh
```

The installer refuses to proceed unless:

1. `HEAD` exactly matches the verified PocketPal base commit.
2. the checkout is clean.
3. the Talent patch passes `git apply --check`.
4. every Xcode-project structural anchor occurs exactly once.

## Required local quality gates

```bash
yarn lint
yarn typecheck
yarn test
```

Because a native iOS module was added, then run:

```bash
cd ios
pod install
open PocketPal.xcworkspace
```

Build to a **physical iPhone**, not only the simulator.

## First physical diagnostic sequence

Do not involve Qwen initially.

1. `getState()` must report `poweredOn` + authorized Bluetooth.
2. `scan(5000)` must return the physical Flipper with advertised service `3080`, `3081`, `3082`, or `3083`.
3. `connect(identifier, 10000)` must complete pairing and return a GATT fingerprint.
4. The fingerprint must contain `61FE`, `62FE`, `63FE`, `64FE` with the expected characteristic properties.
5. `flowControlFreeBytes` must be non-negative and update after connection.

Only after those gates pass should the real protobuf RPC client replace the mock `flipper_status` backend.

## Current stop boundary

The next implementation is the typed `PB.Main` RPC codec/client and first physical `PingRequest`. That should not be wired before the native module has compiled and the physical GATT fingerprint passes; otherwise protobuf and BLE failures become indistinguishable.

See `EVIDENCE.md` and `BUILD_MANIFEST.md` for the evidence chain and gate status.
